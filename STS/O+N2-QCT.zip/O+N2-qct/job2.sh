#!/bin/bash

# Function to get the current number of jobs in the queue for the user

get_job_count() {
    # Replace "yourusername" with your actual username on the cluster
    squeue -u $USER | wc -l
}

# Function to submit jobs
submit_jobs() {
        current_jobs=$(get_job_count)
        echo $current_jobs

        # Subtract 1 to account for the header line in squeue output
        current_jobs=$((current_jobs - 1))
        if [ "$current_jobs" -lt 20 ]; then
                sbatch job$file.sh

            echo "Job submitted. Total jobs in queue: $current_jobs"

            # Optional: Wait a bit before checking the job count again to prevent spamming the scheduler
            sleep 1
        else
            echo "20 jobs are already in the queue. Waiting..."
            # Wait for some time before re-checking the job count
            sleep 60
        fi
}


input_file="N2.dat" # Rovibrational data of the NO diatom  (all accesible states at T=10000 )

# Skip the first line and loop over all rows

#ecol=0.86172800000000005 # Collision energy in eV. 10 000 K

#Sampling the collision energy at 10 000 K using Boltzmanin distribution (see input)


tail -n +2 "$input_file" | while read line; do
ivib=$(echo $line | cut -d' ' -f1)
jrot=$(echo $line | cut -d' ' -f2)
echo "ivib: $ivib, jrot: $jrot"
# Perform any operations you need with $ivib and $jrot here
file=D2-v$ivib.j$jrot   #.E$ecol
cp run.sh job$file.sh

sed -i s/%IVIB%/$ivib/g job$file.sh
sed -i s/%JROT%/$jrot/g job$file.sh
submit_jobs #queueing system
done

